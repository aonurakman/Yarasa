/*
* Copyright 2017 The Android Open Source Project, Inc.
*
* Licensed to the Apache Software Foundation (ASF) under one or more contributor
* license agreements. See the NOTICE file distributed with this work for additional
* information regarding copyright ownership. The ASF licenses this file to you under
* the Apache License, Version 2.0 (the "License"); you may not use this file except
* in compliance with the License. You may obtain a copy of the License at

* http://www.apache.org/licenses/LICENSE-2.0

* Unless required by applicable law or agreed to in writing, software distributed under
* the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF
* ANY KIND, either express or implied. See the License for the specific language
* governing permissions and limitations under the License.

*/

package com.example.yubo.bluepi;

import android.app.ActionBar;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import androidx.fragment.app.FragmentActivity;

import org.jetbrains.annotations.Nullable;

/**
 * Created by yubo on 7/11/17.
 */

/**
 * This fragment controls Bluetooth to communicate with other devices.
 */

public class BluetoothChatFragment extends androidx.fragment.app.DialogFragment {


    private static final String TAG = "BluetoothChatFragment";

    //current connection status
    static String currentStatus = "not connected";

    // Intent request codes
    private static final int REQUEST_CONNECT_DEVICE_SECURE = 1;
    private static final int REQUEST_CONNECT_DEVICE_INSECURE = 2;
    private static final int REQUEST_ENABLE_BT = 3;
    public static final int REQUEST_DIALOG_FRAGMENT = 4;


    // Layout Views
    private ImageView dir1;
    private ImageView dir2;
    private ImageView dir3;
    private ImageView dir4;
    private ImageView dir5;
    private ImageView dir6;
    private ImageView dir7;
    private ImageView dir8;
    private ImageView dir9;


    /**
     * Name of the connected device
     */
    private String mConnectedDeviceName = null;

    /**
     * String buffer for outgoing messages
     */
    private StringBuffer mOutStringBuffer;

    /**
     * Local Bluetooth adapter
     */
    private BluetoothAdapter mBluetoothAdapter = null;

    /**
     * Member object for the chat services
     */
    private BluetoothChatService mChatService = null;

    private static boolean isRead = false;



    @Override
    public void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        // Get local Bluetooth adapter
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        // If the adapter is null, then Bluetooth is not supported
        if (mBluetoothAdapter == null) {
            FragmentActivity activity = getActivity();
            Toast.makeText(activity, "Bluetooth is not available", Toast.LENGTH_LONG).show();
            activity.finish();
        }



    }

    @Override
    public void onStart() {
        super.onStart();

        // If BT is not on, request that it be enabled.
        // setupChat() will then be called during onActivityResult
        if (!mBluetoothAdapter.isEnabled()) {
            Intent enableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableIntent, REQUEST_ENABLE_BT);
            // Otherwise, setup the chat session
        } else if (mChatService == null) {
            setupChat();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        // Performing this check in onResume() covers the case in which BT was
        // not enabled during onStart(), so we were paused to enable it...
        // onResume() will be called when ACTION_REQUEST_ENABLE activity returns.
        if (mChatService != null) {
            // Only if the state is STATE_NONE, do we know that we haven't started already
            if (mChatService.getState() == BluetoothChatService.STATE_NONE) {
                // Start the Bluetooth chat services
                mChatService.start();
            }
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_bluetooth_chat, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        dir1 = (ImageView) view.findViewById(R.id.imageView1);
        dir2 = (ImageView) view.findViewById(R.id.imageView2);
        dir3 = (ImageView) view.findViewById(R.id.imageView3);
        dir4 = (ImageView) view.findViewById(R.id.imageView4);
        dir5 = (ImageView) view.findViewById(R.id.imageView5);
        dir6 = (ImageView) view.findViewById(R.id.imageView6);
        dir7 = (ImageView) view.findViewById(R.id.imageView7);
        dir8 = (ImageView) view.findViewById(R.id.imageView8);
        dir9 = (ImageView) view.findViewById(R.id.imageView9);
    }

    /**
     * Set up the UI and background operations for chat.
     */
    private void setupChat() {
        Log.d(TAG, "setupChat()");

        // Initialize the BluetoothChatService to perform bluetooth connections
        mChatService = new BluetoothChatService(getActivity(), mHandler);

        // Initialize the buffer for outgoing messages
        mOutStringBuffer = new StringBuffer("");
    }

    /**
     * Makes this device discoverable for 300 seconds (5 minutes).
     */
    private void ensureDiscoverable() {
        if (mBluetoothAdapter.getScanMode() !=
                BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE) {
            Intent discoverableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
            discoverableIntent.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300);
            startActivity(discoverableIntent);
        }
    }


    /**
     * Updates the status on the action bar.
     *
     * @param resId a string resource ID
     */
    private void setStatus(int resId) {
        FragmentActivity activity = getActivity();
        if (null == activity) {
            return;
        }
        final ActionBar actionBar = activity.getActionBar();
        if (null == actionBar) {
            return;
        }
        Log.d(TAG, "actionBar.setSubtitle(resId) = " + resId );
        currentStatus = getString(resId);
        actionBar.setSubtitle(resId);

    }

    /**
     * Updates the status on the action bar.
     *
     * @param subTitle status
     */
    private void setStatus(CharSequence subTitle) {
        FragmentActivity activity = getActivity();
        if (null == activity) {
            return;
        }
        final ActionBar actionBar = activity.getActionBar();
        if (null == actionBar) {
            return;
        }
        Log.d(TAG, "actionBar.setSubtitle(subTitle) = " + subTitle );
        currentStatus = subTitle.toString();
        actionBar.setSubtitle(subTitle);
    }

    private String displayData(String data){
        String loc = "";
        String type = "";
        Pattern ptrn1 = Pattern.compile("(.):");
        Pattern ptrn2 = Pattern.compile(".:(.+)");
        Matcher mtc1 = ptrn1.matcher(data);
        if (mtc1.find())
        {
            loc = mtc1.group(1);
        }

        Matcher mtc2 = ptrn2.matcher(data);
        if (mtc2.find())
        {
            type = mtc2.group(1);
        }

        dir1.setBackgroundColor(Color.argb(0,255, 255, 255));
        dir1.setImageResource(android.R.drawable.ic_btn_speak_now);
        dir2.setBackgroundColor(Color.argb(0,255, 255, 255));
        dir2.setImageResource(android.R.drawable.ic_btn_speak_now);
        dir3.setBackgroundColor(Color.argb(0,255, 255, 255));
        dir3.setImageResource(android.R.drawable.ic_btn_speak_now);
        dir4.setBackgroundColor(Color.argb(0,255, 255, 255));
        dir4.setImageResource(android.R.drawable.ic_btn_speak_now);
        dir6.setBackgroundColor(Color.argb(0,255, 255, 255));
        dir6.setImageResource(android.R.drawable.ic_btn_speak_now);
        dir7.setBackgroundColor(Color.argb(0,255, 255, 255));
        dir7.setImageResource(android.R.drawable.ic_btn_speak_now);
        dir8.setBackgroundColor(Color.argb(0,255, 255, 255));
        dir8.setImageResource(android.R.drawable.ic_btn_speak_now);
        dir9.setBackgroundColor(Color.argb(0,255, 255, 255));
        dir9.setImageResource(android.R.drawable.ic_btn_speak_now);

        switch(loc)
        {
            case "1":
                dir1.setBackgroundColor(Color.argb(1, 255, 255, 255));
                dir1.setImageResource(R.drawable.attention);
                break;
            case "2":
                dir2.setBackgroundColor(Color.argb(1, 255, 255, 255));
                dir2.setImageResource(R.drawable.attention);
                break;
            case "3":
                dir3.setBackgroundColor(Color.argb(1, 255, 255, 255));
                dir3.setImageResource(R.drawable.attention);
                break;
            case "4":
                dir4.setBackgroundColor(Color.argb(1, 255, 255, 255));
                dir4.setImageResource(R.drawable.attention);
                break;
            case "6":
                dir6.setBackgroundColor(Color.argb(1, 255, 255, 255));
                dir6.setImageResource(R.drawable.attention);
                break;
            case "7":
                dir7.setBackgroundColor(Color.argb(1, 255, 255, 255));
                dir7.setImageResource(R.drawable.attention);
                break;
            case "8":
                dir8.setBackgroundColor(Color.argb(1, 255, 255, 255));
                dir8.setImageResource(R.drawable.attention);
                break;
            case "9":
                dir8.setBackgroundColor(Color.argb(1, 255, 255, 255));
                dir9.setImageResource(R.drawable.attention);
                break;
            default:
                type = "";
                System.out.println("no match");
        }
        return type;
    }


    /**
     * The Handler that gets information back from the BluetoothChatService
     */
    private final Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            FragmentActivity activity = getActivity();
            switch (msg.what) {
                case Constants.MESSAGE_STATE_CHANGE:
                    switch (msg.arg1) {
                        case BluetoothChatService.STATE_CONNECTED:
                            setStatus(getString(R.string.title_connected_to, mConnectedDeviceName));
                            break;
                        case BluetoothChatService.STATE_CONNECTING:
                            setStatus(R.string.title_connecting);
                            break;
                        case BluetoothChatService.STATE_LISTEN:
                        case BluetoothChatService.STATE_NONE:
                            setStatus(R.string.title_not_connected);
                            break;
                    }
                    break;
                case Constants.MESSAGE_WRITE:
                    isRead = false;
                    byte[] writeBuf = (byte[]) msg.obj;
                    // construct a string from the buffer
                    String writeMessage = new String(writeBuf);
                    Log.d(TAG, "writeMessage = " + writeMessage);
                    Toast.makeText(activity, "Sent!", Toast.LENGTH_LONG).show();
                    break;
                case Constants.MESSAGE_READ:
                    isRead = true;
                    String readMessage = (String)msg.obj;
                    Log.d(TAG, "readMessage = " + readMessage);
                    String type = displayData(readMessage);
                    if(type.length()>0){
                        Toast.makeText(activity, type, Toast.LENGTH_LONG).show();
                    }
                    break;
                case Constants.MESSAGE_DEVICE_NAME:
                    mConnectedDeviceName = msg.getData().getString(Constants.DEVICE_NAME);
                    if (null != activity) {
                        Toast.makeText(activity, "Connected to "
                                + mConnectedDeviceName, Toast.LENGTH_SHORT).show();
                    }
                    break;
                case Constants.MESSAGE_TOAST:
                    if (null != activity) {
                        Toast.makeText(activity, msg.getData().getString(Constants.TOAST),
                                Toast.LENGTH_SHORT).show();
                    }
                    break;
            }
        }
    };

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case REQUEST_CONNECT_DEVICE_SECURE:
                // When DeviceListActivity returns with a device to connect
                if (resultCode == Activity.RESULT_OK) {
                    connectDevice(data, true);
                }
                break;
            case REQUEST_CONNECT_DEVICE_INSECURE:
                // When DeviceListActivity returns with a device to connect
                if (resultCode == Activity.RESULT_OK) {
                    connectDevice(data, false);
                }
                break;
            case REQUEST_ENABLE_BT:
                // When the request to enable Bluetooth returns
                if (resultCode == Activity.RESULT_OK) {
                    // Bluetooth is now enabled, so set up a chat session
                    setupChat();
                } else {
                    // User did not enable Bluetooth or an error occurred
                    Log.d(TAG, "BT not enabled");
                    Toast.makeText(getActivity(), R.string.bt_not_enabled_leaving,
                            Toast.LENGTH_SHORT).show();
                    getActivity().finish();
                }
        }
    }

    /**
     * Establish connection with other device
     *
     * @param data   An {@link Intent} with {@link DeviceListActivity#EXTRA_DEVICE_ADDRESS} extra.
     * @param secure Socket Security type - Secure (true) , Insecure (false)
     */
    private void connectDevice(Intent data, boolean secure) {
        // Get the device MAC address
        String address = data.getExtras()
                .getString(DeviceListActivity.EXTRA_DEVICE_ADDRESS);
        // Get the BluetoothDevice object
        BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(address);
        // Attempt to connect to the device
        mChatService.connect(device, secure);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.bluetooth_chat, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.insecure_connect_scan: {
                // Launch the DeviceListActivity to see devices and do scan
                Intent serverIntent = new Intent(getActivity(), DeviceListActivity.class);
                startActivityForResult(serverIntent, REQUEST_CONNECT_DEVICE_INSECURE);
                return true;
            }
            case R.id.discoverable: {
                // Ensure this device is discoverable by others
                ensureDiscoverable();
                return true;
            }
        }
        return false;
    }



}
